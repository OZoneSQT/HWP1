var timer_8c =
[
    [ "timer_calc_prescaler_and_ocr", "timer_8c.html#af5447f407ee8886ad9a265d88710d4a9", null ],
    [ "timer_init_16bit", "timer_8c.html#a085174722e05ea41f20c949f9248602f", null ],
    [ "timer_init_32bit", "timer_8c.html#ab824fc06a5462eee861a31dee9f5b22a", null ],
    [ "timer_init_8bit", "timer_8c.html#a413bf036400c73b1e2054083d6173aa9", null ]
];