var adc_hal_8c =
[
    [ "ISR", "adc-hal_8c.html#a05c2e5b588ced1cd7312f5b0edc5b295", null ],
    [ "adc_values", "adc-hal_8c.html#a2818ce4063f87c833660f7691ae3df1c", null ]
];