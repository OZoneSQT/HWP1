var settings_8h =
[
    [ "ADCPIN", "settings_8h.html#a21c555c3cebca0a9bef4156fa4ab9c95", null ],
    [ "D1_PIN", "settings_8h.html#af70aafc16e3dd904599982e4784405f4", null ],
    [ "D2_PIN", "settings_8h.html#ab5dc5f30ad937fb8c3ecea4922a8e17e", null ],
    [ "D3_PIN", "settings_8h.html#a93c8addeb4d1481807fbb09a3dd41322", null ],
    [ "D4_PIN", "settings_8h.html#a397c2c535f67a13298ac59cd4a5aba4c", null ],
    [ "DECIMAL", "settings_8h.html#a7c2d2b121faf048e9623df797612378c", null ],
    [ "DELAY_MS", "settings_8h.html#a70fb43de88d474f4c6e87dff47edf851", null ],
    [ "DELAY_S", "settings_8h.html#a77a2f86c61e7b77697571c7d13609465", null ],
    [ "F_CPU", "settings_8h.html#a43bafb28b29491ec7f871319b5a3b2f8", null ],
    [ "MISO_PIN", "settings_8h.html#aecb75580e6d96b71a64123aee5bd3929", null ],
    [ "MOSI_PIN", "settings_8h.html#a11338fccf824b29757c2b23edb0f690f", null ],
    [ "SCLK_PIN", "settings_8h.html#ac9bb6d868837c450a2172efa97326d4a", null ],
    [ "SS_SHIFT_REGISTER", "settings_8h.html#ada93950ce7a05cf54a56ea61a3a61376", null ],
    [ "TYPE", "settings_8h.html#a5a392548f2df67370cb15d2a5d75cd7b", null ],
    [ "USE_SPI", "settings_8h.html#a1acd02cc5bc9a5945addaf6e4f65d39a", null ]
];