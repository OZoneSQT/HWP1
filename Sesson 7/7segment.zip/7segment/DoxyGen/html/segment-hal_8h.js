var segment_hal_8h =
[
    [ "segment_hal_init", "segment-hal_8h.html#ab90cec751e6442d95770d025a0b5b4a1", null ],
    [ "segment_hal_off", "segment-hal_8h.html#aa5525debf166b61cb179d1b28e54a6b0", null ],
    [ "segment_hal_print", "segment-hal_8h.html#a356932e5ddd8b8ea05afc6f96edc38dd", null ]
];