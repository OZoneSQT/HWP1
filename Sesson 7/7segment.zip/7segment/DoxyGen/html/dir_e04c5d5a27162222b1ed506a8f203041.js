var dir_e04c5d5a27162222b1ed506a8f203041 =
[
    [ "key-hal.c", "key-hal_8c.html", "key-hal_8c" ],
    [ "key-hal.h", "key-hal_8h.html", "key-hal_8h" ]
];