var temperature_reader_8c =
[
    [ "temperature_reader_init", "temperature-reader_8c.html#ac72777a408d29e9f4362e9f923202c10", null ],
    [ "temperature_reader_read_float", "temperature-reader_8c.html#aa050c0431eb6e1ba94dd3ed9aca29971", null ]
];