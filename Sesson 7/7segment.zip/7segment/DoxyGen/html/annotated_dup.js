var annotated_dup =
[
    [ "Spi", "struct_spi.html", "struct_spi" ]
];