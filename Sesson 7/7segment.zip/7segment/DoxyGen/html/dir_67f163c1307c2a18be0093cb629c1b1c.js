var dir_67f163c1307c2a18be0093cb629c1b1c =
[
    [ "adc-hal.c", "adc-hal_8c.html", "adc-hal_8c" ],
    [ "adc-hal.h", "adc-hal_8h.html", "adc-hal_8h" ]
];