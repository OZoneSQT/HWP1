var dir_040a9ee1a150e3ba975c5aece91ee6dc =
[
    [ "temperature-reader.c", "temperature-reader_8c.html", "temperature-reader_8c" ],
    [ "temperature-reader.h", "temperature-reader_8h.html", "temperature-reader_8h" ],
    [ "thermometer.c", "thermometer_8c.html", "thermometer_8c" ],
    [ "thermometer.h", "thermometer_8h.html", "thermometer_8h" ]
];