var segment_hal_8c =
[
    [ "segment_hal_init", "segment-hal_8c.html#ab90cec751e6442d95770d025a0b5b4a1", null ],
    [ "segment_hal_off", "segment-hal_8c.html#aa5525debf166b61cb179d1b28e54a6b0", null ],
    [ "segment_hal_on", "segment-hal_8c.html#a50b95f91ec6c5ec1b039b90817799c58", null ],
    [ "segment_hal_print", "segment-hal_8c.html#a356932e5ddd8b8ea05afc6f96edc38dd", null ],
    [ "segments", "segment-hal_8c.html#a33d7505514e1cf943f9fa5bbcbdaa217", null ],
    [ "SPI", "segment-hal_8c.html#a2c09267dc02cc8186f673577c7b73f72", null ]
];