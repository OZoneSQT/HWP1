var temperature_reader_8h =
[
    [ "temperature_reader_init", "temperature-reader_8h.html#ac72777a408d29e9f4362e9f923202c10", null ],
    [ "temperature_reader_read", "temperature-reader_8h.html#ac60c3fe9adad468c8ed9b368f25fb601", null ]
];