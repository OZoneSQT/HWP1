var main_32bit_8c =
[
    [ "F_CPU", "main-32bit_8c.html#a43bafb28b29491ec7f871319b5a3b2f8", null ],
    [ "ISR", "main-32bit_8c.html#ab16889ae984b9b798989a0d239283cac", null ],
    [ "ISR", "main-32bit_8c.html#a3657e3972e59185a247b24ac0153d99c", null ],
    [ "main", "main-32bit_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "timer32_callback", "main-32bit_8c.html#a7903b71d37276bc18892343c3c548f2b", null ],
    [ "timer1_overflow", "main-32bit_8c.html#a95367e91ef2cfad4ea8566fb870c9676", null ]
];