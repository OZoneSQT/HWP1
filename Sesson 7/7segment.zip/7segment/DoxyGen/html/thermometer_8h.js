var thermometer_8h =
[
    [ "thermometer_init", "thermometer_8h.html#a1a0aef46ed41cb44555fcfb6e6940a68", null ],
    [ "thermometer_run", "thermometer_8h.html#a710edf10a8f612c690033993c0327746", null ]
];