var dir_b1f4b0764f4247b637b563990cc01ce6 =
[
    [ "spi-hal.c", "spi-hal_8c.html", "spi-hal_8c" ],
    [ "spi-hal.h", "spi-hal_8h.html", "spi-hal_8h" ]
];