var dir_630c8a91d92d8c7bb6df182d5ad79684 =
[
    [ "adc", "dir_67f163c1307c2a18be0093cb629c1b1c.html", "dir_67f163c1307c2a18be0093cb629c1b1c" ],
    [ "key", "dir_e04c5d5a27162222b1ed506a8f203041.html", "dir_e04c5d5a27162222b1ed506a8f203041" ],
    [ "led", "dir_11b0af726faed2193b97e13cb59fe697.html", "dir_11b0af726faed2193b97e13cb59fe697" ],
    [ "spi", "dir_b1f4b0764f4247b637b563990cc01ce6.html", "dir_b1f4b0764f4247b637b563990cc01ce6" ],
    [ "thermometer", "dir_040a9ee1a150e3ba975c5aece91ee6dc.html", "dir_040a9ee1a150e3ba975c5aece91ee6dc" ],
    [ "timer", "dir_bc71a6c4f91802694b3fbd72da04a179.html", "dir_bc71a6c4f91802694b3fbd72da04a179" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "settings.h", "settings_8h.html", "settings_8h" ]
];