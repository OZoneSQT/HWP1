var segment_8h =
[
    [ "print_t", "segment_8h.html#a08f7c07b55890ba84a5a18ab6bae9caf", [
      [ "INT16_T", "segment_8h.html#a08f7c07b55890ba84a5a18ab6bae9caface7747244a605efdd69ab1edbc1c28d2", null ],
      [ "UINT16_T", "segment_8h.html#a08f7c07b55890ba84a5a18ab6bae9cafa07fc3a954750d581f9889dc9e774b6d8", null ],
      [ "FLOAT", "segment_8h.html#a08f7c07b55890ba84a5a18ab6bae9cafa9cf4a0866224b0bb4a7a895da27c9c4c", null ]
    ] ],
    [ "segment_init", "segment_8h.html#aa25e63ba0d95aa1425ccaec7ee72e7e0", null ],
    [ "segment_print", "segment_8h.html#a45acbb51359a9eb9d3e989e39403af52", null ],
    [ "segment_print_letter", "segment_8h.html#a56f88f5e6eade3fd9bc1bd9f86db3afb", null ]
];