var struct_spi =
[
    [ "edge", "struct_spi.html#ad20a8e3045c532b65afcd6b7d3a639b9", null ],
    [ "format", "struct_spi.html#ac8b8a2640ee6155ea570afc64c3d0ce1", null ],
    [ "mode", "struct_spi.html#a500c16f7901299002158783745bc1ab0", null ],
    [ "speed", "struct_spi.html#a8b008b68344d53e5e8553ab32caea27b", null ],
    [ "ss_pin", "struct_spi.html#ae5fb738f754cc7a762c6cc179079b1d8", null ]
];