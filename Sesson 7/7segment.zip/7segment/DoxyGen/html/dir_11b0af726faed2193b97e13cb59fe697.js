var dir_11b0af726faed2193b97e13cb59fe697 =
[
    [ "letters.h", "letters_8h.html", "letters_8h" ],
    [ "segment-hal.c", "segment-hal_8c.html", "segment-hal_8c" ],
    [ "segment-hal.h", "segment-hal_8h.html", "segment-hal_8h" ],
    [ "segment.c", "segment_8c.html", "segment_8c" ],
    [ "segment.h", "segment_8h.html", "segment_8h" ]
];