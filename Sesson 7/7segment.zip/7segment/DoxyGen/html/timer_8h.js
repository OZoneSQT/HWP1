var timer_8h =
[
    [ "timer_t", "timer_8h.html#a764f517e2e45ad48bcd8b88590ab5276", [
      [ "TIMER_1", "timer_8h.html#a764f517e2e45ad48bcd8b88590ab5276a0be6ca9f568d9237d83970c13199f4b5", null ],
      [ "TIMER_3", "timer_8h.html#a764f517e2e45ad48bcd8b88590ab5276aaf4aeec4d2bfbd5de2fcec6739e1e5a9", null ]
    ] ],
    [ "timer_init_16bit", "timer_8h.html#a085174722e05ea41f20c949f9248602f", null ],
    [ "timer_init_32bit", "timer_8h.html#ab824fc06a5462eee861a31dee9f5b22a", null ],
    [ "timer_init_8bit", "timer_8h.html#a413bf036400c73b1e2054083d6173aa9", null ]
];