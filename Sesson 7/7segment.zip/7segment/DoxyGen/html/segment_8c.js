var segment_8c =
[
    [ "segment_init", "segment_8c.html#aa25e63ba0d95aa1425ccaec7ee72e7e0", null ],
    [ "segment_print", "segment_8c.html#a45acbb51359a9eb9d3e989e39403af52", null ],
    [ "segment_print_letter", "segment_8c.html#a56f88f5e6eade3fd9bc1bd9f86db3afb", null ],
    [ "decimal1", "segment_8c.html#a6d14caebf0dea59f815ff8330b662466", null ],
    [ "decimal2", "segment_8c.html#a000fcb7b6e74206c8978a41040d8ff4b", null ],
    [ "digit1", "segment_8c.html#a4dd954387a388ede47ffd4d23dc432ec", null ],
    [ "digit2", "segment_8c.html#af4e0b224b827154a648d49a8843db2e2", null ],
    [ "digit3", "segment_8c.html#a17cbbe5dd62d1aa10caf455da54edc98", null ],
    [ "digit4", "segment_8c.html#a09118b9294cff8775a9bb6b3aa0f6af9", null ],
    [ "segment1", "segment_8c.html#a2d7ae12700a9170b062fb44a4cf99d15", null ],
    [ "segment2", "segment_8c.html#ad1232a27a7f76d25fc804751f286ba1b", null ],
    [ "segment3", "segment_8c.html#acbe8f17cdaf8f69022281b347cc65379", null ],
    [ "segment4", "segment_8c.html#a88d2d240b3e44a1d3d61be6e7118dda5", null ]
];