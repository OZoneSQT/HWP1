var adc_hal_8h =
[
    [ "adcPin_t", "adc-hal_8h.html#af378a17d8a521aed1e48d2bcdc483401", null ],
    [ "AdcPin", "adc-hal_8h.html#a545e43ed034393cc851d1284bdd0d626", [
      [ "ADC_0", "adc-hal_8h.html#a545e43ed034393cc851d1284bdd0d626aa7f4d8267a3e7e544f3f867f2b429a02", null ],
      [ "ADC_1", "adc-hal_8h.html#a545e43ed034393cc851d1284bdd0d626ac7f9ee52a56e7cb14a6f4ab1104436a1", null ],
      [ "ADC_2", "adc-hal_8h.html#a545e43ed034393cc851d1284bdd0d626a9b15ce3dc96b90458f5c3a1c8e05f8e6", null ],
      [ "ADC_3", "adc-hal_8h.html#a545e43ed034393cc851d1284bdd0d626ae2c2b7b21e22e66c73894b8b1423b332", null ],
      [ "ADC_4", "adc-hal_8h.html#a545e43ed034393cc851d1284bdd0d626a02dd8ff053e7f4a2e090b55f4cab2238", null ],
      [ "ADC_5", "adc-hal_8h.html#a545e43ed034393cc851d1284bdd0d626a2fff1c2f268d83011737ff7ac38370c0", null ],
      [ "ADC_6", "adc-hal_8h.html#a545e43ed034393cc851d1284bdd0d626a76a5bdfd79c729ab14b6cf77498e75fc", null ],
      [ "ADC_7", "adc-hal_8h.html#a545e43ed034393cc851d1284bdd0d626acde258d896f735fd042a121f9a231dbc", null ],
      [ "ADC_8", "adc-hal_8h.html#a545e43ed034393cc851d1284bdd0d626aab7fe862b2625e2af4c67441f0eeeddc", null ],
      [ "ADC_9", "adc-hal_8h.html#a545e43ed034393cc851d1284bdd0d626ab940d890c3734d5474baf92af3c7f0df", null ],
      [ "ADC_10", "adc-hal_8h.html#a545e43ed034393cc851d1284bdd0d626aa9f719a27f29b98faff5c817fd0c7a39", null ],
      [ "ADC_11", "adc-hal_8h.html#a545e43ed034393cc851d1284bdd0d626ab80bf877dae1b8e84879661e850df113", null ],
      [ "ADC_12", "adc-hal_8h.html#a545e43ed034393cc851d1284bdd0d626ae39fdb757f98ce6b4ae835d8c413be88", null ],
      [ "ADC_13", "adc-hal_8h.html#a545e43ed034393cc851d1284bdd0d626a0992532ff2d28601e0c5354a56bef0ba", null ],
      [ "ADC_14", "adc-hal_8h.html#a545e43ed034393cc851d1284bdd0d626a4efa10b29ab50fb090cfe7e0bdc64ad8", null ],
      [ "ADC_15", "adc-hal_8h.html#a545e43ed034393cc851d1284bdd0d626ae693320a2c0da1bd5985106496789025", null ]
    ] ],
    [ "adc_init_10bit", "adc-hal_8h.html#a4e2e69335ee74662c9bd43cc443db71f", null ],
    [ "adc_init_8bit", "adc-hal_8h.html#a6431d073740c8e44a103ab529e0a081d", null ],
    [ "adc_read", "adc-hal_8h.html#ae79a8746eac9b22861091abe6d83120a", null ]
];