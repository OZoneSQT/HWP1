var searchData=
[
  ['edge_0',['edge',['../struct_spi.html#ad20a8e3045c532b65afcd6b7d3a639b9',1,'Spi']]]
];
