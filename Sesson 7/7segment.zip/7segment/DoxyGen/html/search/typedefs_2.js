var searchData=
[
  ['spi_5fedge_5ft_0',['spi_edge_t',['../spi-hal_8h.html#aedc17b0fbeef31683da535a709ed4cd6',1,'spi-hal.h']]],
  ['spi_5fformat_5ft_1',['spi_format_t',['../spi-hal_8h.html#a3719d220c5779783834a07bb9ad2898c',1,'spi-hal.h']]],
  ['spi_5fmode_5ft_2',['spi_mode_t',['../spi-hal_8h.html#aa42ba56d0feb1ed9df8b123c215e30f7',1,'spi-hal.h']]],
  ['spi_5fspeed_5ft_3',['spi_speed_t',['../spi-hal_8h.html#ab2fe3d6be8a57eafbc9112b0bbe16b55',1,'spi-hal.h']]],
  ['spi_5ft_4',['spi_t',['../spi-hal_8h.html#af3a2bddf37201ad4adb4ac669761f88b',1,'spi-hal.h']]]
];
