var searchData=
[
  ['miso_5fpin_0',['MISO_PIN',['../settings_8h.html#aecb75580e6d96b71a64123aee5bd3929',1,'settings.h']]],
  ['mosi_5fpin_1',['MOSI_PIN',['../settings_8h.html#a11338fccf824b29757c2b23edb0f690f',1,'settings.h']]]
];
