var searchData=
[
  ['main_0',['main',['../main_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;main.c'],['../main-16bit_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;main-16bit.c'],['../main-32bit_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;main-32bit.c'],['../main-8bit_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;main-8bit.c']]]
];
