var searchData=
[
  ['format_0',['Format',['../spi-hal_8h.html#ab4e88c89b3b7ea1735996cc4def22d58',1,'spi-hal.h']]]
];
