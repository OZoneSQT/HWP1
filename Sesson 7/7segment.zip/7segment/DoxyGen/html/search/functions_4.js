var searchData=
[
  ['segment_5fhal_5finit_0',['segment_hal_init',['../segment-hal_8c.html#ab90cec751e6442d95770d025a0b5b4a1',1,'segment_hal_init(uint16_t refresh_ms):&#160;segment-hal.c'],['../segment-hal_8h.html#ab90cec751e6442d95770d025a0b5b4a1',1,'segment_hal_init(uint16_t refresh_ms):&#160;segment-hal.c']]],
  ['segment_5fhal_5foff_1',['segment_hal_off',['../segment-hal_8c.html#aa5525debf166b61cb179d1b28e54a6b0',1,'segment_hal_off():&#160;segment-hal.c'],['../segment-hal_8h.html#aa5525debf166b61cb179d1b28e54a6b0',1,'segment_hal_off():&#160;segment-hal.c']]],
  ['segment_5fhal_5fon_2',['segment_hal_on',['../segment-hal_8c.html#a50b95f91ec6c5ec1b039b90817799c58',1,'segment-hal.c']]],
  ['segment_5fhal_5fprint_3',['segment_hal_print',['../segment-hal_8c.html#a356932e5ddd8b8ea05afc6f96edc38dd',1,'segment_hal_print(letters_t segment1, letters_t segment2, letters_t segment3, letters_t segment4):&#160;segment-hal.c'],['../segment-hal_8h.html#a356932e5ddd8b8ea05afc6f96edc38dd',1,'segment_hal_print(letters_t segment1, letters_t segment2, letters_t segment3, letters_t segment4):&#160;segment-hal.c']]],
  ['segment_5finit_4',['segment_init',['../segment_8c.html#aa25e63ba0d95aa1425ccaec7ee72e7e0',1,'segment_init(uint16_t refresh_ms):&#160;segment.c'],['../segment_8h.html#aa25e63ba0d95aa1425ccaec7ee72e7e0',1,'segment_init(uint16_t refresh_ms):&#160;segment.c']]],
  ['segment_5fprint_5',['segment_print',['../segment_8c.html#a45acbb51359a9eb9d3e989e39403af52',1,'segment_print(float value, print_t format, uint8_t decimals):&#160;segment.c'],['../segment_8h.html#a45acbb51359a9eb9d3e989e39403af52',1,'segment_print(float value, print_t format, uint8_t decimals):&#160;segment.c']]],
  ['segment_5fprint_5fletter_6',['segment_print_letter',['../segment_8c.html#a56f88f5e6eade3fd9bc1bd9f86db3afb',1,'segment_print_letter(letters_t segment1, letters_t segment2, letters_t segment3, letters_t segment4):&#160;segment.c'],['../segment_8h.html#a56f88f5e6eade3fd9bc1bd9f86db3afb',1,'segment_print_letter(letters_t segment1, letters_t segment2, letters_t segment3, letters_t segment4):&#160;segment.c']]],
  ['spi_5fdelete_7',['spi_delete',['../spi-hal_8h.html#a396e45ec3979ecfa9c33dc0257b33992',1,'spi-hal.h']]],
  ['spi_5finit_8',['spi_init',['../spi-hal_8c.html#a1be57e8436e1bf2ec68032337fd7c7fa',1,'spi_init(uint16_t *pin,...):&#160;spi-hal.c'],['../spi-hal_8h.html#a1be57e8436e1bf2ec68032337fd7c7fa',1,'spi_init(uint16_t *pin,...):&#160;spi-hal.c']]],
  ['spi_5frx_9',['spi_rx',['../spi-hal_8h.html#a2b16403aea7bc380108aef05931a7734',1,'spi-hal.h']]],
  ['spi_5ftx_10',['spi_tx',['../spi-hal_8h.html#aa1202e28c6acb287c5597f03aa286729',1,'spi-hal.h']]]
];
