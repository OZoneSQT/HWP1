var searchData=
[
  ['use_5fspi_0',['USE_SPI',['../settings_8h.html#a1acd02cc5bc9a5945addaf6e4f65d39a',1,'settings.h']]]
];
