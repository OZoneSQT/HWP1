var searchData=
[
  ['adc_5finit_5f10bit_0',['adc_init_10bit',['../adc-hal_8h.html#a4e2e69335ee74662c9bd43cc443db71f',1,'adc-hal.h']]],
  ['adc_5finit_5f8bit_1',['adc_init_8bit',['../adc-hal_8h.html#a6431d073740c8e44a103ab529e0a081d',1,'adc-hal.h']]],
  ['adc_5fread_2',['adc_read',['../adc-hal_8h.html#ae79a8746eac9b22861091abe6d83120a',1,'adc-hal.h']]]
];
