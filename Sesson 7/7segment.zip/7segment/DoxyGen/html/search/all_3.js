var searchData=
[
  ['f_5fcpu_0',['F_CPU',['../settings_8h.html#a43bafb28b29491ec7f871319b5a3b2f8',1,'F_CPU():&#160;settings.h'],['../main-16bit_8c.html#a43bafb28b29491ec7f871319b5a3b2f8',1,'F_CPU():&#160;main-16bit.c'],['../main-32bit_8c.html#a43bafb28b29491ec7f871319b5a3b2f8',1,'F_CPU():&#160;main-32bit.c'],['../main-8bit_8c.html#a43bafb28b29491ec7f871319b5a3b2f8',1,'F_CPU():&#160;main-8bit.c']]],
  ['float_1',['FLOAT',['../segment_8h.html#a08f7c07b55890ba84a5a18ab6bae9cafa9cf4a0866224b0bb4a7a895da27c9c4c',1,'segment.h']]],
  ['format_2',['format',['../struct_spi.html#ac8b8a2640ee6155ea570afc64c3d0ce1',1,'Spi']]],
  ['format_3',['Format',['../spi-hal_8h.html#ab4e88c89b3b7ea1735996cc4def22d58',1,'spi-hal.h']]]
];
