var searchData=
[
  ['edge_0',['edge',['../struct_spi.html#ad20a8e3045c532b65afcd6b7d3a639b9',1,'Spi']]],
  ['edge_1',['Edge',['../spi-hal_8h.html#a5be7c8fa582f7b873d1c6caacb633073',1,'spi-hal.h']]]
];
