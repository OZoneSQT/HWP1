var searchData=
[
  ['type_0',['TYPE',['../settings_8h.html#a5a392548f2df67370cb15d2a5d75cd7b',1,'settings.h']]]
];
