var searchData=
[
  ['edge_0',['Edge',['../spi-hal_8h.html#a5be7c8fa582f7b873d1c6caacb633073',1,'spi-hal.h']]]
];
