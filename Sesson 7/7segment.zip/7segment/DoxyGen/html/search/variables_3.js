var searchData=
[
  ['format_0',['format',['../struct_spi.html#ac8b8a2640ee6155ea570afc64c3d0ce1',1,'Spi']]]
];
