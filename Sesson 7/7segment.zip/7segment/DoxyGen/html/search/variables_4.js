var searchData=
[
  ['mode_0',['mode',['../struct_spi.html#a500c16f7901299002158783745bc1ab0',1,'Spi']]]
];
