var searchData=
[
  ['float_0',['FLOAT',['../segment_8h.html#a08f7c07b55890ba84a5a18ab6bae9cafa9cf4a0866224b0bb4a7a895da27c9c4c',1,'segment.h']]]
];
