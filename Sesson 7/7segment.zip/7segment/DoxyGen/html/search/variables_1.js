var searchData=
[
  ['decimal1_0',['decimal1',['../segment_8c.html#a6d14caebf0dea59f815ff8330b662466',1,'segment.c']]],
  ['decimal2_1',['decimal2',['../segment_8c.html#a000fcb7b6e74206c8978a41040d8ff4b',1,'segment.c']]],
  ['digit1_2',['digit1',['../segment_8c.html#a4dd954387a388ede47ffd4d23dc432ec',1,'segment.c']]],
  ['digit2_3',['digit2',['../segment_8c.html#af4e0b224b827154a648d49a8843db2e2',1,'segment.c']]],
  ['digit3_4',['digit3',['../segment_8c.html#a17cbbe5dd62d1aa10caf455da54edc98',1,'segment.c']]],
  ['digit4_5',['digit4',['../segment_8c.html#a09118b9294cff8775a9bb6b3aa0f6af9',1,'segment.c']]]
];
