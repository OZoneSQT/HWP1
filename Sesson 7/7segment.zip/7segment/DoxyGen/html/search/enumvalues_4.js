var searchData=
[
  ['spi_5flsb_5ffirst_0',['SPI_LSB_FIRST',['../spi-hal_8h.html#ab4e88c89b3b7ea1735996cc4def22d58a5a6abe145caf9794d5a70e5472ee988f',1,'spi-hal.h']]],
  ['spi_5fmaster_1',['SPI_MASTER',['../spi-hal_8h.html#a46c8a310cf4c094f8c80e1cb8dc1f911a84379dc90398ca075038c8d5ee465f6a',1,'spi-hal.h']]],
  ['spi_5fmsb_5ffirst_2',['SPI_MSB_FIRST',['../spi-hal_8h.html#ab4e88c89b3b7ea1735996cc4def22d58a8912f763c0e7854e08dfbe61b7a57cc6',1,'spi-hal.h']]],
  ['spi_5focs128_3',['SPI_OCS128',['../spi-hal_8h.html#ad57b3fa8e45359906ac229567c209a63a2ac8eb26bf3c6672c51266f707a31b37',1,'spi-hal.h']]],
  ['spi_5focs16_4',['SPI_OCS16',['../spi-hal_8h.html#ad57b3fa8e45359906ac229567c209a63a24c10fbbacebeb3539025fa34773a3f8',1,'spi-hal.h']]],
  ['spi_5focs2_5',['SPI_OCS2',['../spi-hal_8h.html#ad57b3fa8e45359906ac229567c209a63af31b65ceb0f8fa93eee504f312d5dd51',1,'spi-hal.h']]],
  ['spi_5focs32_6',['SPI_OCS32',['../spi-hal_8h.html#ad57b3fa8e45359906ac229567c209a63a94ef1c3039d70ec992462c7feb58f413',1,'spi-hal.h']]],
  ['spi_5focs4_7',['SPI_OCS4',['../spi-hal_8h.html#ad57b3fa8e45359906ac229567c209a63aaf1bd8b3686bea39041f94387c5d1c9e',1,'spi-hal.h']]],
  ['spi_5focs64_8',['SPI_OCS64',['../spi-hal_8h.html#ad57b3fa8e45359906ac229567c209a63a020b0c930f5b99def0576a0cea38c840',1,'spi-hal.h']]],
  ['spi_5focs8_9',['SPI_OCS8',['../spi-hal_8h.html#ad57b3fa8e45359906ac229567c209a63aa86df68ff38cb3f72bf74129fd4200e6',1,'spi-hal.h']]],
  ['spi_5fsclk_5fmode_5f0_5flead_5frise_10',['SPI_SCLK_MODE_0_LEAD_RISE',['../spi-hal_8h.html#a5be7c8fa582f7b873d1c6caacb633073ab2b16c0a3a2916fd1c3ec47e22e6a61d',1,'spi-hal.h']]],
  ['spi_5fsclk_5fmode_5f1_5ftrail_5frise_11',['SPI_SCLK_MODE_1_TRAIL_RISE',['../spi-hal_8h.html#a5be7c8fa582f7b873d1c6caacb633073a576dbfc5a516e8cd5cc517e65b0e829a',1,'spi-hal.h']]],
  ['spi_5fsclk_5fmode_5f2_5flead_5ffall_12',['SPI_SCLK_MODE_2_LEAD_FALL',['../spi-hal_8h.html#a5be7c8fa582f7b873d1c6caacb633073aefc96f43159bf9837e8baffa597c5ba9',1,'spi-hal.h']]],
  ['spi_5fsclk_5fmode_5f3_5ftrail_5ffall_13',['SPI_SCLK_MODE_3_TRAIL_FALL',['../spi-hal_8h.html#a5be7c8fa582f7b873d1c6caacb633073a43b2244007766986ba7acee97e2a5f1d',1,'spi-hal.h']]],
  ['spi_5fslave_14',['SPI_SLAVE',['../spi-hal_8h.html#a46c8a310cf4c094f8c80e1cb8dc1f911abc98c1546fe12d3fceb1f86cf670faa9',1,'spi-hal.h']]]
];
