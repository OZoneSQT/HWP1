var searchData=
[
  ['sclk_5fpin_0',['SCLK_PIN',['../settings_8h.html#ac9bb6d868837c450a2172efa97326d4a',1,'settings.h']]],
  ['ss_5fshift_5fregister_1',['SS_SHIFT_REGISTER',['../settings_8h.html#ada93950ce7a05cf54a56ea61a3a61376',1,'settings.h']]]
];
