var searchData=
[
  ['adcpin_0',['ADCPIN',['../settings_8h.html#a21c555c3cebca0a9bef4156fa4ab9c95',1,'settings.h']]]
];
