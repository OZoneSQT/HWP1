var searchData=
[
  ['temperature_5freader_5finit_0',['temperature_reader_init',['../temperature-reader_8c.html#ac72777a408d29e9f4362e9f923202c10',1,'temperature_reader_init():&#160;temperature-reader.c'],['../temperature-reader_8h.html#ac72777a408d29e9f4362e9f923202c10',1,'temperature_reader_init():&#160;temperature-reader.c']]],
  ['temperature_5freader_5fread_1',['temperature_reader_read',['../temperature-reader_8h.html#ac60c3fe9adad468c8ed9b368f25fb601',1,'temperature-reader.h']]],
  ['temperature_5freader_5fread_5ffloat_2',['temperature_reader_read_float',['../temperature-reader_8c.html#aa050c0431eb6e1ba94dd3ed9aca29971',1,'temperature-reader.c']]],
  ['thermometer_5finit_3',['thermometer_init',['../thermometer_8c.html#a1a0aef46ed41cb44555fcfb6e6940a68',1,'thermometer_init():&#160;thermometer.c'],['../thermometer_8h.html#a1a0aef46ed41cb44555fcfb6e6940a68',1,'thermometer_init():&#160;thermometer.c']]],
  ['thermometer_5frun_4',['thermometer_run',['../thermometer_8c.html#a710edf10a8f612c690033993c0327746',1,'thermometer_run():&#160;thermometer.c'],['../thermometer_8h.html#a710edf10a8f612c690033993c0327746',1,'thermometer_run():&#160;thermometer.c']]],
  ['timer1_5fcallback_5',['timer1_callback',['../main-8bit_8c.html#a2b484ee6fd936ec7faac227b6c57712c',1,'main-8bit.c']]],
  ['timer32_5fcallback_6',['timer32_callback',['../main-32bit_8c.html#a7903b71d37276bc18892343c3c548f2b',1,'main-32bit.c']]],
  ['timer3_5fcallback_7',['timer3_callback',['../main-16bit_8c.html#a109a4568678189087e63d80ed2337700',1,'main-16bit.c']]],
  ['timer_5fcalc_5fprescaler_5fand_5focr_8',['timer_calc_prescaler_and_ocr',['../timer_8c.html#af5447f407ee8886ad9a265d88710d4a9',1,'timer.c']]],
  ['timer_5finit_5f16bit_9',['timer_init_16bit',['../timer_8c.html#a085174722e05ea41f20c949f9248602f',1,'timer_init_16bit(uint8_t time_ms, timer_t timer_number):&#160;timer.c'],['../timer_8h.html#a085174722e05ea41f20c949f9248602f',1,'timer_init_16bit(uint8_t time_ms, timer_t timer_number):&#160;timer.c']]],
  ['timer_5finit_5f32bit_10',['timer_init_32bit',['../timer_8c.html#ab824fc06a5462eee861a31dee9f5b22a',1,'timer_init_32bit(uint32_t time_ms):&#160;timer.c'],['../timer_8h.html#ab824fc06a5462eee861a31dee9f5b22a',1,'timer_init_32bit(uint32_t time_ms):&#160;timer.c']]],
  ['timer_5finit_5f8bit_11',['timer_init_8bit',['../timer_8c.html#a413bf036400c73b1e2054083d6173aa9',1,'timer_init_8bit(uint8_t time_ms):&#160;timer.c'],['../timer_8h.html#a413bf036400c73b1e2054083d6173aa9',1,'timer_init_8bit(uint8_t time_ms):&#160;timer.c']]]
];
