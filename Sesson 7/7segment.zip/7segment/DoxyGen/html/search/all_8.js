var searchData=
[
  ['print_5ft_0',['print_t',['../segment_8h.html#a08f7c07b55890ba84a5a18ab6bae9caf',1,'segment.h']]]
];
