var searchData=
[
  ['segment1_0',['segment1',['../segment_8c.html#a2d7ae12700a9170b062fb44a4cf99d15',1,'segment.c']]],
  ['segment2_1',['segment2',['../segment_8c.html#ad1232a27a7f76d25fc804751f286ba1b',1,'segment.c']]],
  ['segment3_2',['segment3',['../segment_8c.html#acbe8f17cdaf8f69022281b347cc65379',1,'segment.c']]],
  ['segment4_3',['segment4',['../segment_8c.html#a88d2d240b3e44a1d3d61be6e7118dda5',1,'segment.c']]],
  ['segments_4',['segments',['../segment-hal_8c.html#a33d7505514e1cf943f9fa5bbcbdaa217',1,'segment-hal.c']]],
  ['speed_5',['speed',['../struct_spi.html#a8b008b68344d53e5e8553ab32caea27b',1,'Spi']]],
  ['spi_6',['SPI',['../segment-hal_8c.html#a2c09267dc02cc8186f673577c7b73f72',1,'segment-hal.c']]],
  ['ss_5fpin_7',['ss_pin',['../struct_spi.html#ae5fb738f754cc7a762c6cc179079b1d8',1,'Spi']]]
];
