var searchData=
[
  ['speed_0',['Speed',['../spi-hal_8h.html#ad57b3fa8e45359906ac229567c209a63',1,'spi-hal.h']]]
];
