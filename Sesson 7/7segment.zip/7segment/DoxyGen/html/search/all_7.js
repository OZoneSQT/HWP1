var searchData=
[
  ['main_0',['main',['../main_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;main.c'],['../main-16bit_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;main-16bit.c'],['../main-32bit_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;main-32bit.c'],['../main-8bit_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;main-8bit.c']]],
  ['main_2d16bit_2ec_1',['main-16bit.c',['../main-16bit_8c.html',1,'']]],
  ['main_2d32bit_2ec_2',['main-32bit.c',['../main-32bit_8c.html',1,'']]],
  ['main_2d8bit_2ec_3',['main-8bit.c',['../main-8bit_8c.html',1,'']]],
  ['main_2ec_4',['main.c',['../main_8c.html',1,'']]],
  ['miso_5fpin_5',['MISO_PIN',['../settings_8h.html#aecb75580e6d96b71a64123aee5bd3929',1,'settings.h']]],
  ['mode_6',['mode',['../struct_spi.html#a500c16f7901299002158783745bc1ab0',1,'Spi']]],
  ['mode_7',['Mode',['../spi-hal_8h.html#a46c8a310cf4c094f8c80e1cb8dc1f911',1,'spi-hal.h']]],
  ['mosi_5fpin_8',['MOSI_PIN',['../settings_8h.html#a11338fccf824b29757c2b23edb0f690f',1,'settings.h']]]
];
