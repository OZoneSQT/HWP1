/*
 * led_driver.h
 *
 * Created: 19-02-2023 14:29:49
 *  Author: barto
 */ 

#ifndef LED_DRIVER_H_
#define LED_DRIVER_H_

void init_leds();
void set_led(uint8_t led_no, uint8_t state);


#endif 